package com.websocket.geeksforgeeks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeeksforgeeksApplicationTests {

	@Test
	void contextLoads() {
	}

}
